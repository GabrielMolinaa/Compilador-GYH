package teste;

public enum TipoToken {
PCDec, PCProg, PCInt,PCReal,PCLer,PCImprimir,PCSe,PCSenao,PCEntao,
PCEnqto,PCIni,PCFim,OPAritMult,OpAritDiv,OpAritSoma,OpAritSub,
OpRelMenor,OpRelMenorIgual,OpRelMaior,OpRelMaiorIgual,OpRelIgual,
OpRelDif,OpBoolE,OpBoolOu,Delim,Atrib,AbrePar,FechaPar,Var,NumInt,
NumReal,Cadeia,Fim
}
